1:"$Sreact.fragment"
2:I[39756,["/_next/static/chunks/11vs_umig4m4d.js","/_next/static/chunks/0m1f64dn1ktlv.js","/_next/static/chunks/0ylv5gl51djvp.js","/_next/static/chunks/0bdl--y7h5w7v.js","/_next/static/chunks/14d95v2q-d4b-.js"],"default"]
3:I[37457,["/_next/static/chunks/11vs_umig4m4d.js","/_next/static/chunks/0m1f64dn1ktlv.js","/_next/static/chunks/0ylv5gl51djvp.js","/_next/static/chunks/0bdl--y7h5w7v.js","/_next/static/chunks/14d95v2q-d4b-.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"BoQr1HA2clS2ghUVaEi6E"}
