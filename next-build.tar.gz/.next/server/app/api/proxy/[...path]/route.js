var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/proxy/[...path]/route.js")
R.c("server/chunks/[root-of-the-server]__041.y2m._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_proxy_[___path]_route_actions_0n.xh4s.js")
R.m(90260)
module.exports=R.m(90260).exports
