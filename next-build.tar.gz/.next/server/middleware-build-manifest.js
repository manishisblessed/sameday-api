globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/BoQr1HA2clS2ghUVaEi6E/_buildManifest.js",
    "static/BoQr1HA2clS2ghUVaEi6E/_ssgManifest.js",
    "static/BoQr1HA2clS2ghUVaEi6E/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0imfvrlr~2q89.js",
    "static/chunks/04t_9n9yswse7.js",
    "static/chunks/0ttnl3fcetfjp.js",
    "static/chunks/turbopack-0jniznestg45l.js"
  ]
};
